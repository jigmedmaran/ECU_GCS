namespace RoundButtonHost
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.roundButton11 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton10 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton9 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton8 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton7 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton6 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton5 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton4 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton3 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton2 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.roundButton1 = new GaryPerkin.UserControls.Buttons.RoundButton();
            this.SuspendLayout();
            // 
            // roundButton11
            // 
            this.roundButton11.BevelDepth = 6;
            this.roundButton11.Dome = true;
            this.roundButton11.Location = new System.Drawing.Point(172, 136);
            this.roundButton11.Name = "roundButton11";
            this.roundButton11.RecessDepth = 0;
            this.roundButton11.Size = new System.Drawing.Size(78, 57);
            this.roundButton11.TabIndex = 10;
            this.roundButton11.Text = "Cancel";
            this.roundButton11.UseVisualStyleBackColor = true;
            // 
            // roundButton10
            // 
            this.roundButton10.BevelDepth = 5;
            this.roundButton10.BevelHeight = 5;
            this.roundButton10.Dome = true;
            this.roundButton10.Location = new System.Drawing.Point(13, 125);
            this.roundButton10.Name = "roundButton10";
            this.roundButton10.RecessDepth = 0;
            this.roundButton10.Size = new System.Drawing.Size(138, 79);
            this.roundButton10.TabIndex = 9;
            this.roundButton10.Text = "Save";
            this.roundButton10.UseVisualStyleBackColor = true;
            // 
            // roundButton9
            // 
            this.roundButton9.Location = new System.Drawing.Point(274, 76);
            this.roundButton9.Name = "roundButton9";
            this.roundButton9.RecessDepth = 0;
            this.roundButton9.Size = new System.Drawing.Size(50, 128);
            this.roundButton9.TabIndex = 8;
            this.roundButton9.Text = "Vertical";
            this.roundButton9.UseVisualStyleBackColor = true;
            // 
            // roundButton8
            // 
            this.roundButton8.BackColor = System.Drawing.Color.Red;
            this.roundButton8.BevelDepth = 3;
            this.roundButton8.BevelHeight = 2;
            this.roundButton8.Dome = true;
            this.roundButton8.Location = new System.Drawing.Point(199, 76);
            this.roundButton8.Name = "roundButton8";
            this.roundButton8.RecessDepth = 3;
            this.roundButton8.Size = new System.Drawing.Size(69, 50);
            this.roundButton8.TabIndex = 7;
            this.roundButton8.Text = "Cancel";
            this.roundButton8.UseVisualStyleBackColor = false;
            // 
            // roundButton7
            // 
            this.roundButton7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.roundButton7.Dome = true;
            this.roundButton7.Location = new System.Drawing.Point(114, 80);
            this.roundButton7.Name = "roundButton7";
            this.roundButton7.RecessDepth = 3;
            this.roundButton7.Size = new System.Drawing.Size(71, 43);
            this.roundButton7.TabIndex = 6;
            this.roundButton7.Text = "OK";
            this.roundButton7.UseVisualStyleBackColor = false;
            // 
            // roundButton6
            // 
            this.roundButton6.BackColor = System.Drawing.Color.CornflowerBlue;
            this.roundButton6.Location = new System.Drawing.Point(13, 83);
            this.roundButton6.Name = "roundButton6";
            this.roundButton6.RecessDepth = 0;
            this.roundButton6.Size = new System.Drawing.Size(86, 36);
            this.roundButton6.TabIndex = 5;
            this.roundButton6.Text = "OK";
            this.roundButton6.UseVisualStyleBackColor = false;
            // 
            // roundButton5
            // 
            this.roundButton5.Dome = true;
            this.roundButton5.Enabled = false;
            this.roundButton5.Location = new System.Drawing.Point(274, 13);
            this.roundButton5.Name = "roundButton5";
            this.roundButton5.RecessDepth = 3;
            this.roundButton5.Size = new System.Drawing.Size(50, 50);
            this.roundButton5.TabIndex = 4;
            this.roundButton5.Text = "OK";
            this.roundButton5.UseVisualStyleBackColor = true;
            // 
            // roundButton4
            // 
            this.roundButton4.BevelDepth = 2;
            this.roundButton4.BevelHeight = 4;
            this.roundButton4.Dome = true;
            this.roundButton4.Location = new System.Drawing.Point(209, 13);
            this.roundButton4.Name = "roundButton4";
            this.roundButton4.RecessDepth = 4;
            this.roundButton4.Size = new System.Drawing.Size(50, 50);
            this.roundButton4.TabIndex = 3;
            this.roundButton4.Text = "Go";
            this.roundButton4.UseVisualStyleBackColor = true;
            // 
            // roundButton3
            // 
            this.roundButton3.Dome = true;
            this.roundButton3.Location = new System.Drawing.Point(144, 12);
            this.roundButton3.Name = "roundButton3";
            this.roundButton3.RecessDepth = 0;
            this.roundButton3.Size = new System.Drawing.Size(50, 50);
            this.roundButton3.TabIndex = 2;
            this.roundButton3.Text = "Exit";
            this.roundButton3.UseVisualStyleBackColor = true;
            // 
            // roundButton2
            // 
            this.roundButton2.BevelDepth = 2;
            this.roundButton2.BevelHeight = 3;
            this.roundButton2.Location = new System.Drawing.Point(79, 12);
            this.roundButton2.Name = "roundButton2";
            this.roundButton2.RecessDepth = 0;
            this.roundButton2.Size = new System.Drawing.Size(50, 50);
            this.roundButton2.TabIndex = 1;
            this.roundButton2.Text = "Quit";
            this.roundButton2.UseVisualStyleBackColor = true;
            // 
            // roundButton1
            // 
            this.roundButton1.Location = new System.Drawing.Point(13, 13);
            this.roundButton1.Name = "roundButton1";
            this.roundButton1.RecessDepth = 0;
            this.roundButton1.Size = new System.Drawing.Size(50, 50);
            this.roundButton1.TabIndex = 0;
            this.roundButton1.Text = "OK";
            this.roundButton1.UseVisualStyleBackColor = true;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(336, 214);
            this.Controls.Add(this.roundButton11);
            this.Controls.Add(this.roundButton10);
            this.Controls.Add(this.roundButton9);
            this.Controls.Add(this.roundButton8);
            this.Controls.Add(this.roundButton7);
            this.Controls.Add(this.roundButton6);
            this.Controls.Add(this.roundButton5);
            this.Controls.Add(this.roundButton4);
            this.Controls.Add(this.roundButton3);
            this.Controls.Add(this.roundButton2);
            this.Controls.Add(this.roundButton1);
            this.Name = "Form1";
            this.Text = "Round Buttons";
            this.ResumeLayout(false);

        }

        #endregion

        private GaryPerkin.UserControls.Buttons.RoundButton roundButton1;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton2;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton3;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton4;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton5;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton6;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton7;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton8;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton9;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton10;
        private GaryPerkin.UserControls.Buttons.RoundButton roundButton11;





    }
}

